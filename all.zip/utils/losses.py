import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import toml
from torch.utils.tensorboard import SummaryWriter
import os


class RecommendationLoss:
    """
    推荐系统损失函数类，支持多种损失函数类型
    """
    
    def __init__(self, loss_type, device):
        """
        初始化损失函数
        
        Args:
            loss_type: 损失函数类型，支持 'bce', 'bpr', 'triplet', 'cosine_triplet', 'listwise_contrastive', 'focal'
            device: 计算设备
        """
        self.loss_type = loss_type
        self.device = device
        self.cfg = toml.load('./utils/loss_config.toml')



        
        
    def __call__(self, log_feats, pos_embs, neg_embs, loss_mask):
        """
        计算损失函数
        
        Args:
            log_feats: 序列特征表示 [batch_size, seq_len, hidden_dim]
            pos_embs: 正样本embedding [batch_size, seq_len, hidden_dim]
            neg_embs: 负样本embedding [batch_size, seq_len, hidden_dim]
            loss_mask: 损失计算掩码 [batch_size, seq_len]
            
        Returns:
            loss: 计算得到的损失值
        """
        if self.loss_type == 'bce':
            return self._bce_loss(log_feats, pos_embs, neg_embs, loss_mask)
        elif self.loss_type == 'bpr':
            return self._bpr_loss(log_feats, pos_embs, neg_embs, loss_mask)
        elif self.loss_type == 'triplet':
            return self._triplet_loss(log_feats, pos_embs, neg_embs, loss_mask)
        elif self.loss_type == 'cosine_triplet':
            return self._cosine_triplet_loss(log_feats, pos_embs, neg_embs, loss_mask)
        elif self.loss_type == 'listwise_contrastive':
            return self._listwise_contrastive_loss(log_feats, pos_embs, neg_embs, loss_mask)
        elif self.loss_type == 'focal':
            return self._focal_loss(log_feats, pos_embs, neg_embs, loss_mask)
        elif self.loss_type == 'infonce':
            return self._infonce_loss(log_feats, pos_embs, neg_embs, loss_mask)
        else:
            raise ValueError(f"Unsupported loss type: {self.loss_type}")
    
    def _bce_loss(self, log_feats, pos_embs, neg_embs, loss_mask):
        """
        Binary Cross Entropy Loss
        
        计算正样本和负样本的BCE损失
        """


        pos_logits = (log_feats * pos_embs).sum(dim=-1) 
        neg_logits = (log_feats.unsqueeze(1) * neg_embs).sum(dim=-1) 

        pos_labels = torch.ones_like(pos_logits)
        neg_labels = torch.zeros_like(neg_logits)
        indices = (loss_mask == 1)
        indices_neg = (loss_mask.unsqueeze(1).expand(-1, neg_embs.shape[1], -1) == 1)

        alpha = self.cfg['bce']['alpha']
        beta = self.cfg['bce']['beta']
        criterion = nn.BCEWithLogitsLoss(reduction=self.cfg['bce']['reduction'])
        pos_loss = criterion(pos_logits[indices], pos_labels[indices])
        neg_loss = criterion(neg_logits[indices_neg], neg_labels[indices_neg])

        
        return alpha * pos_loss + beta * neg_loss
    
    def _bpr_loss(self, log_feats, pos_embs, neg_embs, loss_mask):
        """
        Bayesian Personalized Ranking Loss
        
        BPR损失：max(0, -log(σ(pos_score - neg_score)))
        """


        pos_scores = (log_feats * pos_embs).sum(dim=-1).unsqueeze(1).expand(-1, neg_embs.shape[1], -1) 
        neg_scores = (log_feats.unsqueeze(1) * neg_embs).sum(dim=-1)  
        

        score_diff = pos_scores - neg_scores 
        
        loss_mask_expanded = loss_mask.unsqueeze(1).expand(-1, neg_embs.shape[1], -1)
        indices = (loss_mask_expanded == 1)
        

        loss = -torch.log(torch.sigmoid(score_diff[indices]) + 1e-8).mean()

        return loss
    
    def _triplet_loss(self, log_feats, pos_embs, neg_embs, loss_mask):
        """
        Triplet Loss
        
        三元组损失：max(0, margin + neg_distance - pos_distance)
        """


        


        pos_distances = torch.norm(log_feats - pos_embs, p=2, dim=-1).unsqueeze(1).expand(-1, neg_embs.shape[1], -1) 
        neg_distances = torch.norm(log_feats.unsqueeze(1) - neg_embs, p=2, dim=-1)  
        loss_mask_expanded = loss_mask.unsqueeze(1).expand(-1, neg_embs.shape[1], -1)
        indices = (loss_mask_expanded == 1)

        margin = self.cfg.get('margin', 1.0)
        loss = F.relu(margin + pos_distances[indices] - neg_distances[indices]).mean()

        return loss
    
    def _cosine_triplet_loss(self, log_feats, pos_embs, neg_embs, loss_mask):
        """
        Cosine Triplet Loss
        
        基于余弦相似度的三元组损失：max(0, margin + neg_similarity - pos_similarity)
        """

        log_feats_norm = F.normalize(log_feats, p=2, dim=-1)
        pos_embs_norm = F.normalize(pos_embs, p=2, dim=-1)
        neg_embs_norm = F.normalize(neg_embs, p=2, dim=-1)

        

        pos_similarities = (log_feats_norm * pos_embs_norm).sum(dim=-1).unsqueeze(1).expand(-1, neg_embs.shape[1], -1) 
        neg_similarities = (log_feats_norm.unsqueeze(1) * neg_embs_norm).sum(dim=-1)  
        
        loss_mask_expanded = loss_mask.unsqueeze(1).expand(-1, neg_embs.shape[1], -1)
        indices = (loss_mask_expanded == 1)
        

        margin = self.cfg.get('margin', 1.0)
        loss = F.relu(margin + neg_similarities[indices] - pos_similarities[indices]).mean()
        
        return loss
    
    def _listwise_contrastive_loss(self, log_feats, pos_embs, neg_embs, loss_mask, temperature=0.1):
        """
        Listwise Contrastive Loss
        
        列表级对比损失，类似于InfoNCE损失
        """
        # 归一化特征
        log_feats_norm = F.normalize(log_feats, p=2, dim=-1)
        pos_embs_norm = F.normalize(pos_embs, p=2, dim=-1)
        neg_embs_norm = F.normalize(neg_embs, p=2, dim=-1)
        
        # 计算相似度得分
        pos_scores = (log_feats_norm * pos_embs_norm).sum(dim=-1) / temperature  # [batch_size, seq_len]
        neg_scores = (log_feats_norm * neg_embs_norm).sum(dim=-1) / temperature  # [batch_size, seq_len]
        
        # 应用掩码
        pos_scores_masked = pos_scores[loss_mask]
        neg_scores_masked = neg_scores[loss_mask]
        
        if pos_scores_masked.size(0) == 0:
            return torch.tensor(0.0, device=log_feats.device, requires_grad=True)
        
        # 对于每个正样本，计算与所有负样本的对比损失
        # 这里简化处理，将正样本和负样本拼接起来计算softmax
        all_scores = torch.stack([pos_scores_masked, neg_scores_masked], dim=1)  # [N, 2]
        
        # 正样本的标签为0（第一个位置）
        targets = torch.zeros(all_scores.size(0), dtype=torch.long, device=log_feats.device)
        
        # 计算交叉熵损失
        loss = F.cross_entropy(all_scores, targets)
        
        return loss
    
    def _focal_loss(self, log_feats, pos_embs, neg_embs, loss_mask, alpha=0.25, gamma=2.0):
        """
        Focal Loss
        
        用于处理样本不平衡问题的损失函数
        FL(p_t) = -α_t * (1-p_t)^γ * log(p_t)
        """
        # 计算正样本和负样本的logits
        pos_logits = (log_feats * pos_embs).sum(dim=-1)  # [batch_size, seq_len]
        neg_logits = (log_feats * neg_embs).sum(dim=-1)  # [batch_size, seq_len]
        
        # 计算概率
        pos_probs = torch.sigmoid(pos_logits)
        neg_probs = torch.sigmoid(neg_logits)
        
        # 应用掩码
        pos_probs_masked = pos_probs[loss_mask]
        neg_probs_masked = neg_probs[loss_mask]
        
        if pos_probs_masked.size(0) == 0:
            return torch.tensor(0.0, device=log_feats.device, requires_grad=True)
        
        # 计算focal loss
        # 对于正样本：FL = -α * (1-p)^γ * log(p)
        pos_focal_weight = alpha * torch.pow(1 - pos_probs_masked, gamma)
        pos_loss = -pos_focal_weight * torch.log(pos_probs_masked + 1e-8)
        
        # 对于负样本：FL = -(1-α) * p^γ * log(1-p)
        neg_focal_weight = (1 - alpha) * torch.pow(neg_probs_masked, gamma)
        neg_loss = -neg_focal_weight * torch.log(1 - neg_probs_masked + 1e-8)
        
        # 平均损失
        total_loss = (pos_loss.mean() + neg_loss.mean()) / 2
        
        return total_loss
    
    def _infonce_loss(self, log_feats, pos_embs, neg_embs, loss_mask):
        """
        InfoNCE Loss
        L_InfoNCE = -[1/(B·L_valid)] × Σ（b=1-B）Σ（l=1-L）[ mask(b,l) × log( exp(sim(q(b,l), p(b,l))/τ) / ( exp(sim(q(b,l), p(b,l))/τ) + Σ（n=1-N）exp(sim(q(b,l), n(b,l,n))/τ) ) ) ]
        """


        

        temperature = self.cfg.get('infonce', {}).get('temperature', 0.1)
        

        query = F.normalize(log_feats, p=2, dim=-1)  
        positive = F.normalize(pos_embs, p=2, dim=-1)  
        negatives = F.normalize(neg_embs, p=2, dim=-1)  # [batch_size, neg_num, seq_len, hidden_dim] 
        
  
        pos_scores = (query * positive).sum(dim=-1) / temperature  
        
   
        neg_scores = (query.unsqueeze(1) * negatives).sum(dim=-1) / temperature  
        

        loss_mask_expanded = loss_mask.unsqueeze(1).expand(-1, neg_embs.shape[1], -1)  # [batch_size, neg_num, seq_len]

        pos_scores_masked = pos_scores[loss_mask == 1]  
        neg_scores_masked = neg_scores[loss_mask_expanded == 1]  
        
        if pos_scores_masked.size(0) == 0:
            return torch.tensor(0.0, device=log_feats.device, requires_grad=True)
        

        neg_num = neg_embs.shape[1]
        neg_scores_reshaped = neg_scores_masked.view(pos_scores_masked.size(0), neg_num)  # [N, neg_num]
        
       
        all_scores = torch.cat([pos_scores_masked.unsqueeze(1), neg_scores_reshaped], dim=1)  # [N, 1 + neg_num]
        
    
        targets = torch.zeros(all_scores.size(0), dtype=torch.long, device=log_feats.device)
        
   
        loss = F.cross_entropy(all_scores, targets)
        
        return loss





class InfoNCELoss(nn.Module):
    """
    InfoNCE损失函数（对比学习中常用）
    """
    
    def __init__(self, temperature=0.1):
        super(InfoNCELoss, self).__init__()
        self.temperature = temperature
    
    def forward(self, query, positive, negatives):
        """
        计算InfoNCE损失
        
        Args:
            query: 查询向量 [batch_size, dim]
            positive: 正样本向量 [batch_size, dim]
            negatives: 负样本向量 [batch_size, num_negatives, dim]
        """
        # 归一化
        query = F.normalize(query, dim=-1)
        positive = F.normalize(positive, dim=-1)
        negatives = F.normalize(negatives, dim=-1)
        
        # 计算正样本得分
        pos_score = torch.sum(query * positive, dim=-1) / self.temperature  # [batch_size]
        
        # 计算负样本得分
        neg_scores = torch.sum(query.unsqueeze(1) * negatives, dim=-1) / self.temperature  # [batch_size, num_negatives]
        
        # 合并得分
        all_scores = torch.cat([pos_score.unsqueeze(1), neg_scores], dim=1)  # [batch_size, 1 + num_negatives]
        
        # 正样本标签为0
        targets = torch.zeros(all_scores.size(0), dtype=torch.long, device=all_scores.device)
        
        # 计算交叉熵损失
        loss = F.cross_entropy(all_scores, targets)
        
        return loss
